using Terraria.ModLoader;

namespace Onyxia
{
	public class Onyxia : Mod
	{
	}
}