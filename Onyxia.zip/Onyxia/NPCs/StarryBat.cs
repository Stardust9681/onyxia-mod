﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;
using Onyxia.Items;
using Onyxia.Items.Placeable;

namespace Onyxia.NPCs
{
	// Party Zombie is a pretty basic clone of a vanilla NPC. To learn how to further adapt vanilla NPC behaviors, see https://github.com/tModLoader/tModLoader/wiki/Advanced-Vanilla-Code-Adaption#example-npc-npc-clone-with-modified-projectile-hoplite
	public class StarryBat : ModNPC
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Starry Bat");
			Main.npcFrameCount[npc.type] = Main.npcFrameCount[NPCID.CaveBat];
		}

		public override void SetDefaults()
		{
			npc.width = 8;
			npc.height = 8;
			if (!Main.hardMode)
			{
				npc.damage = 15;
				npc.defense = 5;
				npc.lifeMax = 58;
			}
			else
			{
				npc.damage = 37;
				npc.defense = 14;
				npc.lifeMax = 124;
			}
			npc.HitSound = SoundID.NPCDeath4;
			npc.DeathSound = SoundID.NPCDeath4;
			npc.value = 60f; //something to multiply the number of coins dropped. *shrugging*
			npc.knockBackResist = 0.8f;
			npc.aiStyle = 2;
			aiType = NPCID.CaveBat;
			animationType = NPCID.CaveBat;
			//banner = Item.NPCtoBanner(NPCID.Zombie);
			//bannerItem = Item.BannerToItem(banner);
		}

		public override float SpawnChance(NPCSpawnInfo spawnInfo)
		{
			return SpawnCondition.Sky.Chance * 0.9f;
		}

		public override void HitEffect(int hitDirection, double damage)
		{
			for (int i = 0; i < 10; i++)
			{
				int dustType = Main.rand.Next(69,71);
				int dustIndex = Dust.NewDust(npc.position, npc.width, npc.height, dustType);
				Dust dust = Main.dust[dustIndex];
				dust.velocity.X = dust.velocity.X + Main.rand.Next(-50, 51) * 0.01f;
				dust.velocity.Y = dust.velocity.Y + Main.rand.Next(-50, 51) * 0.01f;
				dust.scale *= 1f + Main.rand.Next(-30, 31) * 0.02f;
			}
		}

		public override void NPCLoot()
		{
			Item.NewItem(npc.getRect(), ItemID.FallenStar, Main.rand.Next(0, 3));
			if (Main.rand.NextBool(15))
			{
				Item.NewItem(npc.getRect(), ItemType<StarryShard>(), Main.rand.Next(1, 2));
			}
			if(Main.rand.NextFloat() <= 0.02f)
            {
				Item.NewItem(npc.getRect(), ItemType<StarForgery>(), 1);
            }
		}

        public override void PostAI()
        {
			Lighting.AddLight(npc.Center, Color.WhiteSmoke.ToVector3() * 1.4f * Main.essScale);
		}


    }
}
