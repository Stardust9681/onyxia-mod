﻿using IL.Terraria.ID;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Terraria.GameContent.Achievements;
using Onyxia.Items.Placeable;
using Onyxia.Tiles;

namespace Onyxia.NPCs
{
    public class NpcDrops : GlobalNPC
    {
        /*
        bool generateOre1 = true;
        public override void NPCLoot(NPC npc)
        {
            if(npc.type == Terraria.ID.NPCID.Golem)
            {
                if (generateOre1 == true)
                {
                    Main.NewText("The world has sprouted new materials.", 200, 200, 55);
                    for (int i = 0; i < (int)((double)(WorldGen.rockLayer * Main.maxTilesY) * 40E-5); i++)
                    {
                        int X = WorldGen.genRand.Next(0, Main.maxTilesX);
                        int Y = WorldGen.genRand.Next((int)WorldGen.rockLayer, Main.maxTilesY);
                        WorldGen.OreRunner(X, Y, WorldGen.genRand.Next(9, 15), Main.rand.Next(5, 9), (ushort)ModContent.TileType<GodlyxOre_Tile>());
                    }
                }
                generateOre1 = false;
            }

        }*/
        public override void NPCLoot(NPC npc)
        {
            if(true)
            {

            }

        }

    }
}
