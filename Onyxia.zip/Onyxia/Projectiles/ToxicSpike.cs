﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace Onyxia.Projectiles
{
    class ToxicSpike : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("ToxicBlast");
        }
        public override void SetDefaults()
        {
            projectile.width = 13;
            projectile.height = 21;
            projectile.friendly = true;
            projectile.melee = true;
            projectile.tileCollide = true;
            projectile.penetrate = 2;
            projectile.timeLeft = 450;
            projectile.light = 0.2f;
            projectile.ignoreWater = true;
            projectile.extraUpdates = 1;
            projectile.aiStyle = -1;
        }
        public override void AI()
        {
            projectile.rotation = (float)Math.Atan2(projectile.velocity.Y, projectile.velocity.X) + 1.57f;

            for (int i = 0; i < 1; i++)
            {
                if (Main.rand.NextFloat() >= 0.6f)
                {
                    int dustIndex = Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, 107, projectile.velocity.X * 0.2f, projectile.velocity.Y * 0.2f, 80);
                    Dust dust = Main.dust[dustIndex];
                    dust.noGravity = true;
                    dust.velocity.X *= 0.8f;
                    dust.velocity.Y *= 0.8f;
                    dust.scale *= 0.9f;
                }
            }
        }
        public override void OnHitNPC(NPC target, int damage, float knockback, bool crit)
        {
            if (Main.rand.NextFloat() < 0.33f)
                target.AddBuff(BuffID.Venom, 5 * 60); //x * 60 ticks, in this case, 5 * 60, which means 5 sec.
            if (Main.rand.NextFloat() < 0.66f)
                target.AddBuff(BuffID.Poisoned, 10 * 60); //this is 10 sec.
        }
    }
}
