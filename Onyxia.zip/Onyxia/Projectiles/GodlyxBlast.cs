﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace Onyxia.Projectiles
{
    class GodlyxBlast : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("GodlyxBlast");
        }
        public override void SetDefaults()
        {
            projectile.width = 70;
            projectile.height = 30;
            projectile.friendly = true;
            projectile.melee = true;
            projectile.tileCollide = false;
            projectile.penetrate = -1;
            projectile.timeLeft = 300;
            projectile.light = 0.6f;
            projectile.ignoreWater = true;
            projectile.extraUpdates = 1;
            projectile.aiStyle = -1;
        }
        public override void AI()
        {
            projectile.rotation = (float)Math.Atan2(projectile.velocity.Y, projectile.velocity.X) + 1.57f;
            
            for (int i = 0; i < 1; i++)
            {
                if (Main.rand.NextFloat() >= 0.4f)
                {
                    int dustIndex = Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, 222, projectile.velocity.X * 0.2f, projectile.velocity.Y * 0.2f, 80);
                    Dust dust = Main.dust[dustIndex];
                    dust.noGravity = true;
                    dust.velocity.X *= 1.4f;
                    dust.velocity.Y *= 1.4f;
                    dust.scale *= 0.8f;
                }
            }
        }
    }
}
