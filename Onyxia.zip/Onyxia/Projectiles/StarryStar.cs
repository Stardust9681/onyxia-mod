﻿using System;
using Microsoft.Xna.Framework;
using Terraria.ModLoader;
using Terraria.ID;
using Terraria;
using static Terraria.ModLoader.ModContent;
using Onyxia.NPCs;

namespace Onyxia.Projectiles
{
    class StarryStar : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("StarryStar");
        }
        public override void SetDefaults()
        {
            projectile.width = 16;
            projectile.height = 16;
            projectile.friendly = true;
            projectile.magic = true;
            projectile.tileCollide = true;
            projectile.penetrate = 3;
            projectile.timeLeft = 200;
            projectile.light = 0.5f;
            projectile.ignoreWater = true;
            projectile.extraUpdates = 1;
            projectile.aiStyle = -1;
        }
        public override void AI()
        {
            projectile.rotation = (float)Math.Atan2(projectile.velocity.Y, projectile.velocity.X) + 1.57f;

            for (int i = 0; i < 1; i++)
            {
                if (Main.rand.NextFloat() >= 0.5f)
                {
                    int dustIndex = Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, 70, projectile.velocity.X * 0.2f, projectile.velocity.Y * 0.2f, 80);
                    Dust dust = Main.dust[dustIndex];
                    dust.noGravity = true;
                    dust.velocity.X *= 0.7f;
                    dust.velocity.Y *= 0.7f;
                    dust.scale *= 1.1f;
                }
            }
        }
        public override void OnHitNPC(NPC target, int damage, float knockback, bool crit)
        {
            if (target.FullName.Equals("Starry Bat"))
            {
                damage *= 2;
                crit = true;
            }
            else
            {
                knockback += 1f;
            }
                
        }
    }
}
