﻿using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Onyxia.Tiles
{
	public class StarryBrick_Tile : ModTile
	{
		public override void SetDefaults()
		{
			//Main.tileSpelunker[Type] = true; // The tile will be affected by spelunker highlighting
			//Main.tileValue[Type] = 410; // Metal Detector value, see https://terraria.gamepedia.com/Metal_Detector
			Main.tileShine2[Type] = true; // Modifies the draw color slightly.
										  //Main.tileShine[Type] = 1000; // How often tiny dust appear off this tile. Larger is less frequently
			Main.tileMergeDirt[Type] = true;
			Main.tileSolid[Type] = true;
			//Main.tileBlockLight[Type] = true;

			ModTranslation name = CreateMapEntryName();
			name.SetDefault("");
			AddMapEntry(new Color(255, 255, 32), name);

			dustType = 84;
			drop = ItemType<Items.Placeable.StarryBrick>();
			soundType = SoundID.Tink;
			soundStyle = 1;
			mineResist = 2f;
			minPick = 5;
		}
	}
}