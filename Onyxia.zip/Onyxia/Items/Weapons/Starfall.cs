﻿using System;
using Terraria.ModLoader;
using Terraria;
using Terraria.ID;
using static Terraria.ModLoader.ModContent;
using Onyxia.Projectiles;
using Microsoft.Xna.Framework;
using Onyxia.Tiles;

namespace Onyxia.Items.Weapons
{
    class Starfall : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Starfall");
            Tooltip.SetDefault("'A magical book forged at a cruicible of the heavens'");
        }

        public override void SetDefaults()
        {
            item.damage = 26;
            item.knockBack = 6f;
            item.magic = true;
            item.useTime = 17;
            item.useAnimation = 17;
            item.mana = 11;
            item.rare = 3;
            item.shoot = mod.ProjectileType("StarryStar");
            item.shootSpeed = Main.rand.NextFloat(8f, 12f);
            item.useStyle = 5;
            item.autoReuse = true;
            item.noMelee = true;
        }

        /*public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        {
            if (target.FullName.Equals("Starry Bat"))
            {
                item.damage *= 2;
                item.crit = true;
            }
            else
            {
                knockback += 1f;
            }
        }*/

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Book, 5);
            recipe.AddIngredient(ItemType<StarryShard>(), 8);
            recipe.AddTile(TileType<StarForgery_MultiTile>());
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
