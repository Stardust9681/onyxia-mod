﻿using System;
using Terraria.ModLoader;
using Terraria;
using Terraria.ID;
using static Terraria.ModLoader.ModContent;
using Onyxia.Tiles;

namespace Onyxia.Items.Weapons
{
    class StarrySword : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Starry Sword");
            Tooltip.SetDefault("'Super effective against the heavens.'");
        }

        public override void SetDefaults()
        {
            item.damage = 32;
            item.melee = true;
            item.width = 50;
            item.height = 50;
            item.useTime = 19;
            item.useAnimation = 19;
            //item.channel = true;
            //item.noUseGraphic = true;
            //item.noMelee = true;
            item.useStyle = 1;
            item.knockBack = 4;
            item.value = 10000;
            item.rare = 3;
            item.scale = 0.8f;
            //item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            //item.shoot = ProjectileID.FallingStar;
            //item.shootSpeed = 15f;
            item.useTurn = true;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemType<StarryShard>(), 12);
            recipe.AddTile(TileType<StarForgery_MultiTile>());
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
