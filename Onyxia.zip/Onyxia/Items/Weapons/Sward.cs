using Terraria.ID;
using Terraria.ModLoader;

namespace Onyxia.Items.Weapons
{
	public class Sward : ModItem
	{
		public override void SetStaticDefaults() 
		{
            DisplayName.SetDefault("Sward");
            // DisplayName.SetDefault("Sward"); // By default, capitalization in classnames will add spaces to the display name.
            //You can customize the display name here by uncommenting this line.
			Tooltip.SetDefault("'This is the first added item.'" + "\n[c/aa0000:You shouldn't have this..]");
            item.useTurn = true;
		}

		public override void SetDefaults() 
		{
			item.damage = 200;
			item.magic = true;
			item.width = 70;
			item.height = 70;
			item.useTime = 15;
			item.useAnimation = 15;
			item.useStyle = 1;
			item.knockBack = 0;
			item.value = 10000;
			item.rare = 7;
			item.UseSound = SoundID.Item1;
			item.autoReuse = true;
            item.mana = 10;
            item.scale = 1.2f;
            item.buffType = 94;
            item.buffTime = 100;
		}

		/*public override void AddRecipes() 
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.FallenStar, 100);
			recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}*/
	}
}