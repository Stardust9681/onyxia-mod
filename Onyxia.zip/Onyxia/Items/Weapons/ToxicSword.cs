﻿using Microsoft.Xna.Framework;
using Onyxia.NPCs;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Onyxia.Items.Weapons
{
    public class ToxicSword : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Toxicarium Sword");
            Tooltip.SetDefault("'Has a chance to apply venom or poison to your foe.'");
        }

        public override void SetDefaults()
        {
            item.damage = 87;
            item.melee = true;
            item.width = 40;
            item.height = 40;
            item.useTime = 17;
            item.useAnimation = 17;
            //item.channel = true;
            //item.noUseGraphic = true;
            //item.noMelee = true;
            item.useStyle = 1;
            item.knockBack = 6;
            item.value = 10000;
            item.rare = 4;
            item.scale = 1.2f;
            //item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.shoot = mod.ProjectileType("ToxicSpike");
            item.shootSpeed = 10f;
            item.useTurn = true;
        }

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            type = mod.ProjectileType("ToxicSpike");
            int spread = 5;
            float spreadMult = 0.05f;
            for (int i = 0; i < 2; i++)
            {
                float vX = speedX + (float)Main.rand.Next(-spread, spread + 1) * spreadMult;
                float vY = speedY + (float)Main.rand.Next(-spread, spread + 1) * spreadMult;
                Projectile.NewProjectile(position.X, position.Y, vX, vY, type, damage, knockBack, Main.myPlayer);
            }
            return false;
        }

        public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        {
            if (Main.rand.NextFloat() < 0.33f)
                target.AddBuff(BuffID.Venom, 5 * 60); //x * 60 ticks, in this case, 5 * 60, which means 5 sec.
            if (Main.rand.NextFloat() < 0.66f)
                target.AddBuff(BuffID.Poisoned, 10 * 60); //this is 10 sec.
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemType<ToxicBar>(), 8);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
