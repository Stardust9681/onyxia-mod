﻿using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Onyxia.Items.Weapons
{
    public class GodlyxSword : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Godlyx Sword");
            Tooltip.SetDefault("'It could level a village with one blow... or it could not.'");
        }

        public override void SetDefaults()
        {
            item.damage = 107;
            item.melee = true;
            item.width = 40;
            item.height = 40;
            item.useTime = 22;
            item.useAnimation = 22;
            //item.channel = true;
            //item.noUseGraphic = true;
            //item.noMelee = true;
            item.useStyle = 1;
            item.knockBack = 7;
            item.value = 70000;
            item.rare = 7;
            item.scale = 1.2f;
            //item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.shoot = mod.ProjectileType("GodlyxBlast");
            item.shootSpeed = 7f;
            item.useTurn = true;
        }

        public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        {
            if (Main.rand.NextFloat() < 0.33f)
            {
                target.AddBuff(BuffID.SoulDrain, 5 * 60); //x * 60 ticks, in this case, 5 * 60, which means 5 sec.
                player.AddBuff(BuffID.RapidHealing, 10 * 60);
            }
        }

        /*
        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            
        }*/

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ModContent.ItemType<GodlyxBar>(), 12);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
