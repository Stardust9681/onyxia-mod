﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Configuration;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Onyxia.Items.Weapons
{
    class GodlyxBow : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Godlyx Bow");
            Tooltip.SetDefault("Transforms normal arrows into spears of light. \n77% chance to consume ammo.");
        }
        public override void SetDefaults()
        {
            item.damage = 45;
            item.ranged = true;
            item.noMelee = true;
            item.useAmmo = AmmoID.Arrow;
            item.useStyle = 5;
            item.useTime = 19;
            item.useAnimation = 19;
            item.autoReuse = true;
            item.scale = 0.8f;
            item.rare = 7;
            item.UseSound = SoundID.Item4;

            item.shoot = ProjectileID.PoisonFang; //Defines what projectile is shot, if no ammo is given.
            item.shootSpeed = 20f;
        }
        public override bool ConsumeAmmo(Player player) //Changing boolean to decide if it consumes ammo or not.
        {
            return Main.rand.NextFloat() >= .23f; //Generates a random float between 0 and 1, and if that number is >= to x (.33f), then it will consume ammo.
        }
        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack) //This lets you modify the firing of the item
        {

            int spread = 20; //The angle of random spread.
            int takeShots = 0;
            if (type == ProjectileID.WoodenArrowFriendly)
                takeShots = 2;
            else
                takeShots = 0;
            float spreadMult = 0.1f; //Multiplier for bullet spread. Usually best kept at lower values (like 0.1f)
            if (type == ProjectileID.WoodenArrowFriendly) //Use any ProjectileID here
            {
                for (int i = 0; i < takeShots; i++)
                {
                    type = ProjectileID.HeatRay;

                    float vX = speedX + (float)Main.rand.Next(-spread, spread + 1) * spreadMult;
                    float vY = speedY + (float)Main.rand.Next(-spread, spread + 1) * spreadMult;
                    Projectile.NewProjectile(position.X, position.Y, vX, vY, type, damage, knockBack, Main.myPlayer);
                    type = ProjectileID.WoodenArrowFriendly;
                }
            }
            if (takeShots != 0)
                return false; //Makes sure to not spawn the original projectile (The projectile initially defined in item.shoot = xyz)
            else
                return true;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ModContent.ItemType<GodlyxBar>(), 12);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
