﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Configuration;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Onyxia.Items.Weapons
{
    class ToxicBow : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Toxicarium Bow");
            Tooltip.SetDefault("Transforms normal arrows into piercing fangs." + "\n33% chance to not consume ammo.");
        }
        public override void SetDefaults()
        {
            item.damage = 24;
            item.ranged = true;
            item.noMelee = true;
            item.useAmmo = AmmoID.Arrow;
            item.useStyle = 5;
            item.useTime = 12;
            item.useAnimation = 12;
            item.autoReuse = true;
            item.scale = 0.8f;
            item.rare = 4;

            item.shoot = ProjectileID.PoisonFang; //Defines what projectile is shot, if no ammo is given.
            item.shootSpeed = 20f;
        }
        public override bool ConsumeAmmo(Player player) //Changing boolean to decide if it consumes ammo or not.
        {
            return Main.rand.NextFloat() >= .33f; //Generates a random float between 0 and 1, and if that number is >= to x (.33f), then it will consume ammo.
        }
        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack) //This lets you modify the firing of the item
        {
            
            int spread = 20; //The angle of random spread.
            int takeShots = 0;
            if (type == ProjectileID.WoodenArrowFriendly)
                takeShots = 3;
            else
                takeShots = 1;
            float spreadMult = 0.15f; //Multiplier for bullet spread. Usually best kept at lower values (like 0.1f)
            for (int i = 0; i < takeShots; i++)
            {
                if (type == ProjectileID.WoodenArrowFriendly) //Use any ProjectileID here
                {
                    if (i == 0) //Detects *where* you are in the for loop.
                    {
                        //item.shootSpeed = 20f;
                        type = ProjectileID.VenomFang; //Use any ProjectileID here. Defines what projectile is shot.
                    }
                    else
                    {
                        //item.shootSpeed = 10f;
                        type = ProjectileID.PoisonFang;
                    }
                }
                float vX = speedX + (float)Main.rand.Next(-spread, spread + 1) * spreadMult;
                float vY = speedY + (float)Main.rand.Next(-spread, spread + 1) * spreadMult;
                Projectile.NewProjectile(position.X, position.Y, vX, vY, type, damage, knockBack, Main.myPlayer);
                type = ProjectileID.WoodenArrowFriendly;
            }
            return false; //Makes sure to not spawn the original projectile (The projectile initially defined in item.shoot = xyz)
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ModContent.ItemType<ToxicBar>(), 12);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
