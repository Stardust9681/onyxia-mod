﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Onyxia.Items.Placeable
{
    class ToxicOre : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Toxicarium Ore");
            // DisplayName.SetDefault("<name>"); // By default, capitalization in classnames will add spaces to the display name.
            //You can customize the display name here by uncommenting this line.
            Tooltip.SetDefault("Sizzles in your hand as you hold it.");
            //item.useTurn = true; //This line would otherwise allow you to turn whilst still using the item (good for swords and such)
        }

        public override void SetDefaults()
        {
            item.width = 15;
            item.height = 15;
            item.useTime = 14;
            item.useAnimation = 14;
            item.useStyle = 1; //See list of usestyles here: https://tconfig.fandom.com/wiki/List_of_UseStyles
            item.maxStack = 999;
            item.value = 10000; //Item value: pp/gg/ss/cc
            item.rare = 4; //Item rarity
            item.createTile = TileType<Tiles.ToxicOre_Tile>();
            item.consumable = true;
            //item.UseSound = SoundID.Item1; //Would be used for Sounds, but I don't know them all.
            item.autoReuse = true; //Autoswing (y/n)?
            item.scale = 1; //Item scale on use
            item.useTurn = true;
        }
        /*
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.ChlorophyteOre, 5);
            recipe.AddIngredient(ItemID.RottenChunk, 5);
            recipe.AddIngredient(ItemID.CursedFlame, 1);
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(this, 5);
            recipe.AddRecipe();
            //ModRecipe recipe1 = new ModRecipe(mod); //Maybe uncomment this when other materials are added?
        }*/
    }
}
