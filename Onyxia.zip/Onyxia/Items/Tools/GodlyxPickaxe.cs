﻿using Microsoft.Xna.Framework;
using Steamworks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Onyxia.Items.Tools
{
    class GodlyxPickaxe : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Godlyx Pickaxe");
            Tooltip.SetDefault("'It is said to wield godly pickaxe power..'");
            item.useTurn = true;
        }
        public override void SetDefaults()
        {
            item.damage = 20;
            item.melee = true;
            item.height = 20;
            item.width = 20;
            item.pick = 220;
            //item.axe = 21;
            item.autoReuse = true;
            item.useTime = 7;
            item.useAnimation = 15;
            item.useStyle = 1; //essential for item to work?
            item.rare = 7;
            item.value = 10000;
            item.knockBack = 7;
            item.useTurn = true;
        }
        public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        {
            target.AddBuff(BuffID.SoulDrain, 5 * 60); //Add custom life drain buff.
            player.AddBuff(BuffID.RapidHealing, 5 * 60);
            //Execute "AddBuff()" on the target, using BuffID.<Buff name>, and x*60 ticks, where x is the number of seconds (in this case, 5)
        }
        public override void MeleeEffects(Player player, Rectangle hitbox)
        {
            if (Main.rand.NextBool())
            {
                if (Main.rand.NextBool())
                {
                    //Dust.NewDust(player.position, player.width, player.height, 15, 0f, 0f, 150, default(Color), 1.1f);
                    Dust.NewDust(player.position, player.width, player.height, 200, 1f, 1f, 160, default(Color), 1f);
                }
            }
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemType<GodlyxBar>(), 12);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
