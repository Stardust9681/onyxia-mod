﻿using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Onyxia.Items.Accessories
{
    class CorruptMiningEmblem : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Corrupt Mining Emblem");
            Tooltip.SetDefault("+20% mining speed\nProficient with cursed flames\n'Empowered by all-consuming, cursed fire.");
        }
        public override void SetDefaults()
        {
            item.rare = ItemRarityID.Blue;
            item.accessory = true;
        }
        public override void UpdateEquip(Player player)
        {
            player.pickSpeed -= 0.20f;
            player.allDamage += 0.05f;
            player.buffImmune[BuffID.CursedInferno] = true;
            player.AddBuff(BuffID.WeaponImbueCursedFlames, 1, true);
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemType<MiningEmblem>(), 1);
            recipe.AddIngredient(ItemID.CursedFlame, 20);
            recipe.AddIngredient(ItemID.EbonstoneBlock, 100);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
