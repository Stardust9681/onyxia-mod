﻿using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Onyxia.Items.Accessories
{
    class MiningEmblem : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Mining Emblem");
            Tooltip.SetDefault("+15% mining speed\nA powerful tool you earned from not mining.\nGet back to it!");
        }
        public override void SetDefaults()
        {
            item.rare = ItemRarityID.Blue;
            item.accessory = true;
        }
        public override void UpdateEquip(Player player)
        {
            player.pickSpeed -= 0.15f;
        }
    }
}
