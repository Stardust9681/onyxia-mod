﻿using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Onyxia.Items.Accessories
{
    class StarryShield : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Starry Shield");
            Tooltip.SetDefault("'May you be protected by the celestial bodies in the heavens.'");
        }
        public override void SetDefaults()
        {
            item.rare = 3;
            item.accessory = true;
        }
        public override void UpdateEquip(Player player)
        {
            player.noKnockback = true;
            player.statLifeMax2 += 15;
            player.buffImmune[BuffID.TheTongue] = true;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemType<StarryShard>(), 10);
            recipe.AddIngredient(ItemID.CobaltShield, 1);
            recipe.AddTile(TileID.TinkerersWorkbench);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
