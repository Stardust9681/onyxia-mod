﻿using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Onyxia.Items.Accessories
{
    class CrimsonMiningEmblem : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Crimson Mining Emblem");
            Tooltip.SetDefault("+25% mining speed.\nProficient with ichor.\n'Empowered by the blood of gods.'");
        }
        public override void SetDefaults()
        {
            item.rare = ItemRarityID.Blue;
            item.accessory = true;
        }
        public override void UpdateEquip(Player player)
        {
            player.pickSpeed -= 0.25f;
            player.meleeDamage += 0.10f;
            player.buffImmune[BuffID.Ichor] = true;
            player.AddBuff(BuffID.WeaponImbueIchor, 1, true);
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemType<MiningEmblem>(), 1);
            recipe.AddIngredient(ItemID.Ichor, 20);
            recipe.AddIngredient(ItemID.CrimstoneBlock, 100);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
