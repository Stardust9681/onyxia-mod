﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;

namespace Onyxia.Items
{
    class ToxicBar : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Toxicarium Bar");
            // DisplayName.SetDefault("<name>"); // By default, capitalization in classnames will add spaces to the display name.
            //You can customize the display name here by uncommenting this line.
            //Tooltip.SetDefault("");
            //item.useTurn = true; //This line would otherwise allow you to turn whilst still using the item (good for swords and such)
        }

        public override void SetDefaults()
        {
            item.width = 15;
            item.height = 15;
            item.useTime = 14;
            item.useAnimation = 14;
            item.useStyle = 1; //See list of usestyles here: https://tconfig.fandom.com/wiki/List_of_UseStyles
            item.maxStack = 99;
            item.value = 20000; //Item value: pp/gg/ss/cc
            item.rare = 4; //Item rarity
                           //item.UseSound = SoundID.Item1; //Would be used for Sounds, but I don't know them all.
            item.autoReuse = true; //Autoswing (y/n)?
            item.scale = 1; //Item scale on use
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ModContent.ItemType<Placeable.ToxicOre>(), 4);
            recipe.AddTile(TileID.AdamantiteForge);
            recipe.SetResult(this);
            recipe.AddRecipe();
            //ModRecipe recipe1 = new ModRecipe(mod); //Maybe uncomment this when other materials are added?
        }
    }
}
