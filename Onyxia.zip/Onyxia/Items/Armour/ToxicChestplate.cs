﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Onyxia.Items.Armour
{
	[AutoloadEquip(EquipType.Body)]
	public class ToxicChestplate : ModItem
	{
		public override void SetStaticDefaults()
		{
			base.SetStaticDefaults();
			DisplayName.SetDefault("Toxicarium Chestplate");
			Tooltip.SetDefault("\nImmunity to 'Poisoned'"
				+ "\n+5% damage");
		}

		public override void SetDefaults()
		{
			item.width = 18;
			item.height = 18;
			item.value = 10000;
			item.rare = 4;
			item.defense = 18;
		}

		public override void UpdateEquip(Player player)
		{
			player.buffImmune[BuffID.Poisoned] = true;
			//player.statManaMax2 += 20; //Increase max mana
			//player.maxMinions++; //Increase number of minions
			player.allDamage += 0.05f;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ModContent.ItemType<ToxicBar>(), 16);
			recipe.AddTile(TileID.MythrilAnvil);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}