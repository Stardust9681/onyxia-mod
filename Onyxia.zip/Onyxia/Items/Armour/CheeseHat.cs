﻿using Terraria;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;
using Terraria.ID;
using Onyxia.Items;
using Onyxia.Items.Armour;

namespace Onyxia.Items.Armour
{
	[AutoloadEquip(EquipType.Head)]
	public class CheeseHat : ModItem
	{
		public override void SetStaticDefaults()
		{
			Tooltip.SetDefault("'Not the CHEESE!");
		}

		public override void SetDefaults()
		{
			item.width = 18;
			item.height = 18;
			item.value = 1000000000;
			item.rare = 16;
			item.defense = 19;

			item.useStyle = 2;
			item.useAnimation = 15;
			item.useTime = 15;
			item.buffType = BuffID.WellFed; //Apply buff: <id>
			item.buffTime = 120*60*60; //How long does the buff last (ticks)?
			item.consumable = true;
		}

		public override void UpdateEquip(Player player)
		{
			player.AddBuff(BuffID.WellFed, 60);
			
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.LunarOre, 50);
			recipe.AddTile(TileID.CookingPots);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}