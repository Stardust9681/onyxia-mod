﻿using Terraria;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;
using Terraria.ID;
using Onyxia.Items;
using Onyxia.Items.Armour;

namespace Onyxia.Items.Armour
{
	[AutoloadEquip(EquipType.Head)]
	public class ToxicHelmet : ModItem
	{
		public override void SetStaticDefaults()
		{
			Tooltip.SetDefault("\n+2 Minions"+"\n+40 mana");
		}

		public override void SetDefaults()
		{
			item.width = 18;
			item.height = 18;
			item.value = 10000;
			item.rare = 4;
			item.defense = 14;
		}

		public override void UpdateEquip(Player player)
		{
			//player.buffImmune[BuffID.Poisoned] = true; //Immunity to buff(s).
			player.statManaMax2 += 40; //Increase max mana
			player.maxMinions += 2; //Increase number of minions
			//player.allDamage += 0.05f; //Damage increase
		}

		public override bool IsArmorSet(Item head, Item body, Item legs) //A check to see if the player is wearing the rest of the armour. Returns true if so.
		{
			return body.type == ItemType<ToxicChestplate>() && legs.type == ItemType<ToxicLegs>();
		}

		public override void UpdateArmorSet(Player player) //Kinda like.. if(above){this}.
		{
			player.setBonus = "Provides large increases to most stats, grants +50 max hp.";
			player.allDamage += 0.05f;
			player.endurance += 0.05f;
			player.statLifeMax2 += 50;
			player.statDefense += 3;
			player.moveSpeed += .1f;
			player.pickSpeed += 0.1f;
			player.meleeSpeed += 0.05f;
			/* Here are the individual weapon class bonuses.
			player.meleeDamage -= 0.2f;
			player.thrownDamage -= 0.2f;
			player.rangedDamage -= 0.2f;
			player.magicDamage -= 0.2f;
			player.minionDamage -= 0.2f;
			*/
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemType<ToxicBar>(), 12);
			recipe.AddTile(TileID.MythrilAnvil);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}