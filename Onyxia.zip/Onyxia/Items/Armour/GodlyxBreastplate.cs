﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Onyxia.Items.Armour
{
	[AutoloadEquip(EquipType.Body)]
	public class GodlyxBreastplate : ModItem
	{
		public override void SetStaticDefaults()
		{
			base.SetStaticDefaults();
			DisplayName.SetDefault("Godlyx Chestplate");
			Tooltip.SetDefault("Allows for a dash\n'Cheese armour?'\n'No, not cheese armour.'");
		}

		public override void SetDefaults()
		{
			item.width = 18;
			item.height = 18;
			item.value = 10000;
			item.rare = 7;
			item.defense = 40;
		}

		public override void UpdateEquip(Player player)
		{
			player.dash = 2;
			//player.statManaMax2 += 20; //Increase max mana
			//player.maxMinions++; //Increase number of minions
			
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ModContent.ItemType<GodlyxBar>(), 16);
			recipe.AddTile(TileID.MythrilAnvil);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}