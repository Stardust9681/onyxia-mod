﻿using Onyxia.Items.Accessories;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Onyxia.Items
{
	public class BossBags : GlobalItem
	{
		public override void OpenVanillaBag(string context, Player player, int arg)
		{
			// Typically you'll also want to also add an item to the non-expert boss drops, that code can be found in ExampleGlobalNPC.NPCLoot. Use this and that to add drops to bosses.
			if (context == "bossBag" && arg == ItemID.WallOfFleshBossBag)
			{
				if(Main.rand.NextFloat() <= 0.2f)
				player.QuickSpawnItem(ItemType<MiningEmblem>(), 1);
			}
			if(context == "crate" && arg == ItemID.GoldenCrate)
            {
				if (Main.rand.NextFloat() <= 0.02f)
					player.QuickSpawnItem(ItemID.LifeCrystal, Main.rand.Next(1, 2));
            }
		}
	}
}