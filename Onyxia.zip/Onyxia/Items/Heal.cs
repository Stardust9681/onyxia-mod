using Terraria.ID;
using Terraria.ModLoader;

namespace Onyxia.Items
{
	public class Heal : ModItem
	{
		public override void SetStaticDefaults() 
		{
            DisplayName.SetDefault("Glass of Healing");
            // DisplayName.SetDefault("Sward"); // By default, capitalization in classnames will add spaces to the display name.
            //You can customize the display name here by uncommenting this line.
			Tooltip.SetDefault("'Heals the user rapidly.. at a price.'" + "\n[c/aa0000:You shouldn't have this..]");
            //item.useTurn = true; //This line would otherwise allow you to turn whilst still using the item (good for swords and such)
		}

		public override void SetDefaults() 
		{
            //item.damage = 200; //Damage, if any, for the item
            //item.magic = true; //Damage type
            item.width = 20;
			item.height = 20;
			item.useTime = 15;
			item.useAnimation = 15;
			item.useStyle = 2; //See list of usestyles here: https://tconfig.fandom.com/wiki/List_of_UseStyles
            //item.knockBack = 0; //knockback value, if any
			item.value = 50000; //Item value: pp/gg/ss/cc
			item.rare = 2; //Item rarity
			//item.UseSound = SoundID.Item1; //Would be used for Sounds, but I don't know them all.
			item.autoReuse = false; //Autoswing (y/n)?
            item.mana = 100; //Amount of mana used, if any.
            item.scale = 1; //Item scale on use
            item.buffType = 174; //Apply buff: <id>
            item.buffTime = 300; //How long does the buff last (ticks)?
            item.healLife = 80; //Heals user for <amount>.
            //item.potion = true; //Defines this as a healing potion. (when un-commented)
		}

		/*public override void AddRecipes() 
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.FallenStar, 15);
            recipe.AddIngredient(ItemID.Bottle, 1);
			recipe.AddTile(TileID.Benches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}*/
	}
}