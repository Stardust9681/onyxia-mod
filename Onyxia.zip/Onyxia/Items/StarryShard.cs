﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.DataStructures;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;
using Onyxia.Tiles;

namespace Onyxia.Items
{
    class StarryShard : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Starry Shard");
            // DisplayName.SetDefault("<name>"); // By default, capitalization in classnames will add spaces to the display name.
            //You can customize the display name here by uncommenting this line.
            Tooltip.SetDefault("'This feels so light that it could float into the heavens.'");
            
            Main.RegisterItemAnimation(item.type, new DrawAnimationVertical(7, 10));
            ItemID.Sets.ItemNoGravity[item.type] = true;
        }

        public override void SetDefaults()
        {
            item.width = 17;
            item.height = 17;
            //item.useStyle = 1; //See list of usestyles here: https://tconfig.fandom.com/wiki/List_of_UseStyles
            item.maxStack = 99;
            item.value = 20000; //Item value: pp/gg/ss/cc
            item.rare = 5; //Item rarity
                           //item.UseSound = SoundID.Item1; //Would be used for Sounds, but I don't know them all.
            //item.autoReuse = true; //Autoswing (y/n)?
            item.scale = 1.5f; //Item scale on use
        }

        public override void PostUpdate()
        {
            Lighting.AddLight(item.Center, Color.WhiteSmoke.ToVector3() * 0.7f * Main.essScale);
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.FallenStar, 5);
            recipe.AddTile(TileType<StarForgery_MultiTile>());
            recipe.SetResult(this, 2);
            recipe.AddRecipe();
        }
    }
}
